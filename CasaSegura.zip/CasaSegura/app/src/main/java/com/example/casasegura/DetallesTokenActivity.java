package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class DetallesTokenActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {

    private TextView nombreTxt, fechaTxt, comentarioTxt;
    private String nombre, apellido, fecha, comentario;
    private String id_tbltoken;
    RequestQueue requestQueue;
 //   public static final String IP_SERVER = "http://192.168.0.12/";
    public static final String IP_SERVER = "http://192.168.1.41/";
    JsonObjectRequest jsonObjectRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_token);
        nombreTxt = findViewById(R.id.txtNombre);
        fechaTxt = findViewById(R.id.txtFecha);
        comentarioTxt = findViewById(R.id.txtComentario);
        requestQueue = Volley.newRequestQueue(this);
        traerDatos();
        consultaRegistrosEntradas();
    }

    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.id_tbltoken= bundle.getString("id_tbltoken");
    }

    private void consultaRegistrosEntradas() {
        String url;
        url = IP_SERVER+"/php_android/detallestoken.php?id_tbltoken="+id_tbltoken;
        jsonObjectRequest= new JsonObjectRequest(Request.Method.GET,url,null,this,this );
        requestQueue.add(jsonObjectRequest);
    }


    public void onClick(View view) {
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(getApplicationContext(), "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(getApplicationContext(), "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(getApplicationContext(), "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(getApplicationContext(), "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        JSONArray jsonArray = response.optJSONArray("token");
        try{
            JSONObject jsonObject = null;
            jsonObject = jsonArray.getJSONObject(0);

            this.nombre=jsonObject.optString("nombre_visitante");
            this.apellido=jsonObject.optString("apellido_visitante");
            this.fecha=jsonObject.optString("fecha");
            this.comentario=jsonObject.optString("descripcion");
            nombreTxt.setText(nombre + " "+apellido);
            fechaTxt.setText(fecha);
            comentarioTxt.setText(comentario);

        }catch (Exception e){
            Toast.makeText(this, "" + e, Toast.LENGTH_SHORT).show();
        }
    }
}
