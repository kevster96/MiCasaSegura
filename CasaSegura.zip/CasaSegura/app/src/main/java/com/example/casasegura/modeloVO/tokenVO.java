package com.example.casasegura.modeloVO;

public class tokenVO {
    private String token;
    private String nombre_visita;
    private String apellido_visita;
    private Long dpi;
    private String descripcion;
    private int id_usuario;

    public tokenVO(){

    }

    public tokenVO(String token, String nombre_visita, String apellido_visita, Long dpi, String descripcion, int id_usuario) {
        this.token = token;
        this.nombre_visita = nombre_visita;
        this.apellido_visita = apellido_visita;
        this.dpi = dpi;
        this.descripcion = descripcion;
        this.id_usuario = id_usuario;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNombre_visita() {
        return nombre_visita;
    }

    public void setNombre_visita(String nombre_visita) {
        this.nombre_visita = nombre_visita;
    }

    public String getApellido_visita() {
        return apellido_visita;
    }

    public void setApellido_visita(String apellido_visita) {
        this.apellido_visita = apellido_visita;
    }

    public Long getDpi() {
        return dpi;
    }

    public void setDpi(Long dpi) {
        this.dpi = dpi;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }
}


