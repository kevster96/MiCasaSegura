package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.casasegura.cargando.CargandoDialog;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * IniciarSesionActivity, aca se pedira el usuario y contrasena del usuario
 *
 *
 * @author  Kevin Lezana
 * @version 1.0
 * @since   2020-07-31
 */

public class IniciarSesionActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {

    private EditText usuarioTxt;
    private EditText contrasenaTxt;
    public static final String IP_SERVER = "http://192.168.0.12/";
    private RequestQueue requestQueue;
    private JsonObjectRequest jsonObjectRequest;
    private String nombre, apellido;
    private int id, usuario_activo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion);
        usuarioTxt = findViewById(R.id.usuarioTxt);
        contrasenaTxt = findViewById(R.id.contrasenaTxt);
        requestQueue = Volley.newRequestQueue(this);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            //  Toast.makeText(this, "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            //    Toast.makeText(this, "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            //    Toast.makeText(this, "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            //  Toast.makeText(this, "parse error", Toast.LENGTH_SHORT).show();
        } else {
            //  Toast.makeText(this, "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        /**
         * Este metodo nos regresara nuestro objeto JSON y luego nosotros asignaremos los valores a nuestras variables
         */

        JSONArray jsonArray = response.optJSONArray("usuario");
        try{
            JSONObject jsonObject = null;
            jsonObject = jsonArray.getJSONObject(0);

            this.id = jsonObject.optInt("id_tblusuario");
            this.nombre=jsonObject.optString("nombre");
            this.apellido=jsonObject.optString("apellido");
            this.usuario_activo=jsonObject.optInt("usuario_activo");
        }catch (Exception e){
            Toast.makeText(this, "" + e, Toast.LENGTH_SHORT).show();
        }
    }


    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnacceder:
                //Aca se validad que las cajas de texto no esten vacias
                if(!usuarioTxt.getText().toString().isEmpty() & !contrasenaTxt.getText().toString().isEmpty()){
                    // si las cajas de texto estan llenas, se corre nuestro metodo iniciarSesion
                    iniciarSesion();
                    //aca se instancia nuestro objeto CargandoDialog
                    final CargandoDialog cargandoDialog = new CargandoDialog(IniciarSesionActivity.this);
                    //aca se utiliza el metodo abrirAlertDialog para mostrar nuestro objeto cargandoDialog
                    cargandoDialog.abrirAlertDialog();
                    //Se instancia Handler que nos servira para hacer un pequena demora para que los metodos iniciarSesion
                    // y onResponse puedan correr y asignar los valores a nuestras variables
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //este metodo cierra nuestro cargandoDialog
                                cargandoDialog.cerrarAlertDialog();
                                //si nuestro metodo onResponse regreso Error
                                if(nombre.equals("ERROR")){
                                    Toast.makeText(IniciarSesionActivity.this, "Usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                                }
                                //se revisa que el usuario este activo
                                else if(usuario_activo==1){
                                    Intent intent = new Intent(getApplicationContext(), GeneralActivity.class);
                                    intent.putExtra("id", id);
                                    intent.putExtra("nombre", nombre);
                                    intent.putExtra("apellido", apellido);
                                    startActivity(intent);
                                }
                                // en caso la cuenta este inactiva se muestra el siguiente toast
                                else{
                                    Toast.makeText(IniciarSesionActivity.this, "Cuenta inactiva", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }, 6000);



                }else{
                    Toast.makeText(this, "Por favor ingrese su usuario y contraseña.", Toast.LENGTH_SHORT).show();
                }

                break;
        }

    }

    public void iniciarSesion(){
        /**
        * En este metodo se hace la consulta a la base de datos, este metodo desencadena el metodo onResponse
         *
         */

        try{
            String url;
            url = IP_SERVER+"/php_android/login2.php?usuario="+usuarioTxt.getText().toString()+"&contrasena="+contrasenaTxt.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,url,null,this,this);
            requestQueue.add(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
        }
    }
}
