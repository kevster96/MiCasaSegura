package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class GeneralActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general);
    }

    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btncrear:
                Intent intent = new Intent(getApplicationContext(), TokenActivity.class);
                startActivity(intent);
                break;
            case R.id.btnregistros:
                Intent intent1 = new Intent(getApplicationContext(), RegistrosActivity.class);
                startActivity(intent1);
                break;

        }
    }
}
