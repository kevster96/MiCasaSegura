package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class GeneralActivity extends AppCompatActivity {
    private TextView tituloTxt;
    private String nombre, apellido;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general);
        tituloTxt = findViewById(R.id.tituloTxt);
        traerDatos();
        agregarDatos();
    }

    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.id= bundle.getInt("id");
        this.nombre = bundle.getString("nombre");
        this.apellido = bundle.getString("apellido");
    }

    public void agregarDatos(){
        this.tituloTxt.setText("Bienvenido "+this.nombre+" "+this.apellido);
    }

    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btncrear:
                Intent intent = new Intent(getApplicationContext(), TokenActivity.class);
                intent.putExtra("id", this.id);
                intent.putExtra("apellido", this.apellido);
                startActivity(intent);
                break;
            case R.id.btnregistros:
                Intent intent1 = new Intent(getApplicationContext(), RegistrosActivity.class);
                intent1.putExtra("id", this.id);
                startActivity(intent1);
                break;
            case R.id.btnlistadotoken:
                Intent intent2 = new Intent(getApplicationContext(), ListadoTokenActivity.class);
                intent2.putExtra("id", this.id);
                startActivity(intent2);
                break;

        }
    }
}
