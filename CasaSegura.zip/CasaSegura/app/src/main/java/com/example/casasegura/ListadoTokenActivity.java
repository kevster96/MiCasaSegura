package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.casasegura.modeloVO.registroVO;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class ListadoTokenActivity extends AppCompatActivity  implements Response.Listener<JSONObject>, Response.ErrorListener{

    private int id;
    private String fecha;
    private EditText txtFecha;
    private ListView lista;
    public final Calendar c = Calendar.getInstance();
    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);
    RequestQueue requestQueue;
    public static final String IP_SERVER = "http://192.168.1.41/";
    JsonObjectRequest jsonObjectRequest;
    ArrayList<String> listaDatos;
    ArrayList<registroVO> listaregistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_token);
        txtFecha = findViewById(R.id.txtFecha);
        lista = findViewById(R.id.listaMostrar);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        traerDatos();

    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imgFecha:
                fechaCalendario();
                break;
            case R.id.imgSearch:
                consultaRegistrosToken();
                break;
        }
    }

    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.id= bundle.getInt("id");
    }

    private void consultaRegistrosToken() {
        fecha = txtFecha.getText().toString();
        String url;
        url = IP_SERVER+"/php_android/listadotokens.php?fk_usuario="+this.id+"&fecha="+this.fecha;
        jsonObjectRequest= new JsonObjectRequest(Request.Method.GET,url,null,this,this );
        requestQueue.add(jsonObjectRequest);

    }
    @Override
    public void onErrorResponse(VolleyError error) {

        if (error instanceof TimeoutError) {
            Toast.makeText(getApplicationContext(), "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(getApplicationContext(), "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(getApplicationContext(), "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(getApplicationContext(), "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        registroVO registroVo = null;

        JSONArray jsonArray = response.optJSONArray("registro");
        listaregistro = new ArrayList<>();
        try{
            for (int i = 0; i<jsonArray.length(); i ++){
                registroVo = new registroVO();
                JSONObject jsonObject = null;
                jsonObject = jsonArray.getJSONObject(i);

                registroVo.setToken(jsonObject.optString("id_tbltoken"));
                registroVo.setFecha(jsonObject.optString("nombre_visitante"));
                registroVo.setHora(jsonObject.optString("apellido_visitante"));
                listaregistro.add(registroVo);

            }

            listaDatos = new ArrayList<>();
            for (int i = 0; i<listaregistro.size(); i++){
                listaDatos.add(listaregistro.get(i).getToken()+" - "+listaregistro.get(i).getFecha()+" - "+listaregistro.get(i).getHora());
            }

            ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, listaDatos);
            lista.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fechaCalendario() {
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;
                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? 0 + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);
                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? 0 + String.valueOf(mesActual) : String.valueOf(mesActual);

                String anio = String.valueOf(year);
                //Muestro la fecha con el formato deseado
                txtFecha.setText(anio + "/" + mesFormateado + "/" + diaFormateado);



            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
            /**
             *También puede cargar los valores que usted desee
             */
        }, anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();

    }
}
