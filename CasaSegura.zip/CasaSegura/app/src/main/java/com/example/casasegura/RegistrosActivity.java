package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class RegistrosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registros);
    }

    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btnEntradas:
                Toast.makeText(this, "Se muestra listado de entradas ", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnSalidas:
                Toast.makeText(this, "Se muestra listado de salidas", Toast.LENGTH_SHORT).show();
                break;

        }
    }
}
