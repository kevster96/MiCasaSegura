package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class TokenActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener  {
    private int id ;
    private String apellido;
    private TextView tokenTxt,txtFecha;
    private EditText nombreTxt, apellidoTxt,dpiTxt,comentarioTxt;
    public final Calendar c = Calendar.getInstance();
    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);
    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;
  //  public static final String IP_SERVER = "http://192.168.0.12/";
  public static final String IP_SERVER = "http://192.168.1.41/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_token);
        traerDatos();
        tokenTxt = findViewById(R.id.tokenTxt);
        nombreTxt = findViewById(R.id.nombreTxt);
        apellidoTxt = findViewById(R.id.apellidoTxt);
        dpiTxt = findViewById(R.id.dpiTxt);
        comentarioTxt = findViewById(R.id.comentatioTxt);
        txtFecha = findViewById(R.id.txtFecha);
        requestQueue = Volley.newRequestQueue(this);
    }

    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.id= bundle.getInt("id");
        this.apellido=bundle.getString("apellido");
    }

    public String crearToken(){
        String token ="";
        ArrayList<String> abecedario = new ArrayList<>();
        abecedario.add("a");
        abecedario.add("b");
        abecedario.add("c");
        abecedario.add("d");
        abecedario.add("e");
        abecedario.add("f");
        abecedario.add("g");
        abecedario.add("h");
        abecedario.add("i");
        abecedario.add("j");
        abecedario.add("k");
        abecedario.add("l");
        abecedario.add("m");
        abecedario.add("n");
        abecedario.add("o");
        abecedario.add("p");
        abecedario.add("q");
        abecedario.add("r");
        abecedario.add("s");
        abecedario.add("t");
        abecedario.add("u");
        abecedario.add("v");
        abecedario.add("w");
        abecedario.add("x");
        abecedario.add("y");
        abecedario.add("z");
        abecedario.add("aa");
        abecedario.add("ab");
        abecedario.add("ac");
        abecedario.add("ad");
        abecedario.add("ae");
        abecedario.add("af");

        Date fecha = new Date();
        int mes = fecha.getMonth();
        int id = this.id;
        int hora = fecha.getHours();
        char primeraLetraApellido = this.apellido.charAt(0);
        int minuto = fecha.getMinutes();
        int segundo = fecha.getSeconds();
        int dia = fecha.getDay();
        token = abecedario.get(mes) + id + hora + primeraLetraApellido + minuto + segundo + abecedario.get(dia);
        return token;
}

    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btnToken:
       // Toast.makeText(this, ""+crearToken(), Toast.LENGTH_SHORT).show();
       // tokenTxt.setText(crearToken());
                insertarToken();
                break;
            case R.id.imgFecha:
                fechaCalendario();
                break;
    }

    }

    private void insertarToken(){
        String url;
        if(!nombreTxt.getText().toString().isEmpty() && !apellidoTxt.getText().toString().isEmpty()
        && !dpiTxt.getText().toString().isEmpty()&& !comentarioTxt.getText().toString().isEmpty()){
        String newtoken = crearToken();
            try {
                url = IP_SERVER+"php_android/insertarsw.php?id_tbltoken="+newtoken
                +"&nombre_visitante="+nombreTxt.getText().toString()
                +"&apellido_visitante="+apellidoTxt.getText().toString()
                +"&dpi="+dpiTxt.getText().toString()
                +"&descripcion="+comentarioTxt.getText().toString()
                +"&fecha="+txtFecha.getText().toString()
                +"&fk_usuario="+this.id;

                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, null, this);
                requestQueue.add(jsonObjectRequest);
                tokenTxt.setText(newtoken);
               // Toast.makeText(this, "Datos Ingresados", Toast.LENGTH_SHORT).show();
            }catch (Exception e){
                Toast.makeText(this, "Error desconocido", Toast.LENGTH_SHORT).show();
            }

        }else{
            Toast.makeText(this, "Falta ingresar datos", Toast.LENGTH_SHORT).show();
        }
    }

    private void fechaCalendario() {
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;
                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? 0 + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);
                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? 0 + String.valueOf(mesActual) : String.valueOf(mesActual);

                String anio = String.valueOf(year);
                //Muestro la fecha con el formato deseado
                txtFecha.setText(anio + "/" + mesFormateado + "/" + diaFormateado);



            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
            /**
             *También puede cargar los valores que usted desee
             */
        }, anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();

    }

    @Override
    public void onErrorResponse(VolleyError error) {

        if (error instanceof TimeoutError) {

            Toast.makeText(this, "error_network_timeout", Toast.LENGTH_SHORT).show();
            //  Toast.makeText(this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            // Toast.makeText(this, "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            // Toast.makeText(this, "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            // Toast.makeText(this, "parse error", Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(this, "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(this, "Token creado", Toast.LENGTH_SHORT).show();
    }
}
